import React, { useState, useEffect } from 'react';
import { useDate } from './customHooks/useDate'
import { useFetch } from './customHooks/useFetch'
import axios from 'axios'

export default function Functional() {
    const [count, setCount] = useState(0)
    const [price,setPrice]=useState(100)
    const date = useDate()
  // const data = useFetch("https://jsonpldgcfhvbjhxfdhdgfaceholder.typicode.com/photos");

    // useEffect(() => {
    //     console.log('Without dependency useeffect(ComponentdidUpdate or Mount)')
    // })

  // useEffect(() => {
  //   axios.get("https://jsonpldgcfhvbjhxfdhdgfaceholder.typicode.com/photos")
  //     .then((response) => console.log(response))
  //     .catch(e => console.log(e.message))
  // }, []);
    
    useEffect(() => {
      console.log("With empty array dependency useeffect(ComponentDidMount)");
    }, []);
    
    useEffect(() => {
      console.log("With count dependency useeffect(ComponentDidUpdate)");
    }, [count]);

    useEffect(() => {
      console.log("With price dependency useeffect(ComponentDidUpdate)");
    }, [price]);

   useEffect(() => {
     return () => {
       console.log("Component unmount");
     };
   }, []);
    
    
    const onCountDecrement = () => {
        setCount(c=>c-1)
    }
    
    const onCountIncrement = () => {
        setCount(c=>c+1)
    }

    const onPriceDecrement = () => {
      setPrice((c) => c - 100);
    };

    const onPriceIncrement = () => {
      setPrice((c) => c + 100);
    };
   
    console.log(count,price,date)
    return (
        <React.Fragment>
            <h2>Today is :{date}</h2>
        <div className="d-flex w-50 justify-content-around mt-4">
          <button onClick={onCountDecrement}>-</button>
          <h2>{count}</h2>
          <button onClick={onCountIncrement}>+</button>
        </div>
        <div className="d-flex w-50 justify-content-around mt-4">
          <button onClick={onPriceDecrement}>-</button>
          <h2>{price}</h2>
          <button onClick={onPriceIncrement}>+</button>
        </div>
      </React.Fragment>
    );
}