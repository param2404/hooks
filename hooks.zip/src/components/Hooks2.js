import React, { useState,useRef, useEffect } from 'react'

export default function Hooks() {
    const [name, setName] = useState('')
    const [lastName, setLastName] = useState("");
    const cursor = useRef()
    const cursorLast=useRef()
    
    useEffect(() => {
       cursor.current.focus() 
    },[])

    const editName = (e) => {
        setName(e.target.value)
    }
    const editLastName = (e) => {
      setLastName(e.target.value);
    };

    const submit = (e) => {
        e.preventDefault();
        console.log('submitted')
    }

    const changeFocus = () => {
      // console.log(cursorLast.current)
        cursorLast.current.focus()
    }
    
    return (
      <React.Fragment>
        <form onSubmit={submit}>
          <input type="number" value={1} readOnly></input>
          <br />
          <input
            type="text"
            placeholder="Enter Name"
            value={name}
            onChange={(e) => editName(e)}
            ref={cursor}
            ></input>
            <br/>
          <input
            type="text"
            placeholder="Enter Last Name"
            value={lastName}
            onChange={(e) => editLastName(e)}
            ref={cursorLast}
          ></input>
          <br />
          <button onClick={changeFocus}>Change focus to Last name</button>
        </form>
      </React.Fragment>
    );
}