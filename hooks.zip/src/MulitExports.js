export const abc = 'Hello'

export const bcd="Bye"